
#include "project.h"
#include <stdio.h>
#include <stdlib.h>

// NAVIGATION
#define LINE_N        100
#define TIME_MIN      100
#define TIME_MAX      400
#define CENTER_T      262 // time value when servo's wheels are centered
#define PWM_STRAIGHT  1500
#define PWM_LEFT      1000
#define PWM_RIGHT     2000
#define STEER_PERIOD_MS 20

// PID constants for the Servo angling
volatile float Kp_Servo = 3.0f;
volatile float Kd_Servo = 5.0f;

volatile uint16 minT = 0xFFFF;
volatile uint16 maxT = 0;
volatile uint8  found = 0;
volatile uint16 lastTime = 0;
volatile uint32 isrCount = 0;

float prevError = 0;
// prints no value under a sentinel reading
uint8 noLine = 0;
// stores direction of the last angle of the wheels in case no line is read
uint32 lastSteer = 0;


// SPEED CONTROL

// Proportional coefficient of PID
volatile double kp = 1200;
// Integral coefficient of PID
volatile double ki = 3;
// integ * Ki represents the integral term, measuring the error history
double integ = 0.0;

// safe maximum and minimum values of the PWM
// MAX = 75%
double PWM_MAX = 1800.0;
// MIN = 12.5%
double PWM_MIN = 300.0;

// Bias term: Makes the system go 4 ft/sec on flat ground
double u0 = 1200.0;

// timer begins at "last"
uint32_t last = 4294967295;
// current time that the hall interrupt is occuring
uint32 new;
// last - new: necessary for speed calculations
uint32 elapsed;

// array to store information to print
char speedvalue[25];

// Calculated speed: v = cf/5n; c(wheel) = 0.708
double speed;
// calculated duty from PID to make the car go closer to 4 ft/ sec
double duty;


volatile uint8 armed = 0;
volatile uint8 hall_flag = 0;


// STEERING

char printBuf[60];

volatile uint32 msTicks = 0;   // 1 ms system tick for 1,000,000 Hz clock frequency


static int setServo(int value)
{
    // checks that the servo doesn't steer out of bounds
    if (value < PWM_LEFT)  value = PWM_LEFT;
    if (value > PWM_RIGHT) value = PWM_RIGHT;
    PWM_Servo_WriteCompare((uint16)value);
    return value;
}


// ISR

// Called every 1 ms to track elapsed time, denotes when to update steering
void SysTickCallback(void)
{
    msTicks++;
}

// When the button is pressed, arm the car, prevent integral windeup, and make the car go at the bias PWM value
CY_ISR(Button_Press_ISR)
{
    armed = 1;
    PWM_Motor_WriteCompare(u0);
    integ = 0;

    // Center the steering servo when the car is armed
    setServo(PWM_STRAIGHT);
}


// When the hall effect sensor senses a magnet, set the flag and read the timer register for when it occured
CY_ISR(isr_Hall)
{
    hall_flag = 1;
    Timer_Hall_ReadStatusRegister();
}


// Navigation interrupt for detecting black
CY_ISR(BlackCaptureHandler)
{
    Timer_Camera_ReadStatusRegister();
    isrCount++;
    uint16 time = Timer_Camera_ReadPeriod() - Timer_Camera_ReadCapture();
    lastTime = time;

    if (time > TIME_MIN && time < TIME_MAX)
    {
        // Between the first and last capture of the black line to show in the middle of it.
        if (time < minT) minT = time;
        if (time > maxT) maxT = time;
        found = 1;
    }
}


// Steering PID Control

static void steeringControl(void)
{
    // ensures ISR doesn't interrupt between reading values
    uint8 st = CyEnterCriticalSection();

    // smallest black pixel time reading
    uint16 minimumTime = minT;
    uint8  lineDetected  = found;
    uint16 lastCaptureTime = lastTime;
    uint32 interruptCount  = isrCount;
    // next time is set relative to these values
    minT = 0xFFFF; // highest possible for 16 bit
    maxT = 0; // lowest possible for 16 bit
    found = 0;
    // Read and reset navigation measurements
    CyExitCriticalSection(st);


    if (lineDetected)
    {
        // error is measured between the minimum time detected and the center constant, to adjust for the difference
        float error = (float)minimumTime - CENTER_T;

        // corrects for sentient values read
        if (noLine) { prevError = error; noLine = 0; }

        // calculates error differential for Kd
        float deriv = error - prevError;
        prevError = error;

        // PD formula
        int command = setServo(PWM_STRAIGHT - (int)(Kp_Servo * error + Kd_Servo * deriv));

        // UART: servo command (1000 = full left, 1500 = straight, 2000 = full right)
        sprintf(printBuf, "Servo: %d\r\n", command);
        UART_PutString(printBuf);
    }
    else
    {
        // debug code
        noLine = 1;
        sprintf(printBuf, "No line (isr=%lu last=%u)\r\n", (unsigned long)interruptCount, lastCaptureTime);
        UART_PutString(printBuf);
    }
}


int main(void)
{

    CyGlobalIntEnable;

    // speed control setup
    Timer_Hall_Start();
    PWM_Motor_Start();
    UART_Start();
    isr_Button_StartEx(Button_Press_ISR);

    // Navigation startup

    // 1 ms tick
    CySysTickStart();
    CySysTickSetCallback(0, SysTickCallback);

    // for line detection
    VDAC_Start();
    Comp_Start();
    LineCounter_Start();
    LineCounter_WriteCompare(LINE_N); // looks at the 100th line
    Timer_Camera_Start();
    Black_Capture_StartEx(BlackCaptureHandler);

    // Steering
    PWM_Servo_Start();

    lastSteer = msTicks;

    for (;;)
    {
        // Only start reading the hall sensor when the car is armed
        if (armed == 1){
            isr_Hall_StartEx(isr_Hall);
        }

        // When the hall flag is set
        if (hall_flag == 1){
            // calculate the amount of ticks since the last hall flag
            new = Timer_Hall_ReadCapture();
            elapsed = last - new;
            last = new;

            // print the elapsed time to the UART
            sprintf(speedvalue, "Time: %lu \r\n", elapsed);
            UART_PutString(speedvalue);


            // Calculate speed
            speed = 141600.0 / elapsed;
            // print the speed to the UART
            sprintf(speedvalue, "Speed: %f \r\n", speed);
            UART_PutString(speedvalue);

            // calculate the integral: integ = error * change in time
            // error = 4.0 - current speed
            // change in time = number of ticks since the last hall / frequency
            integ += (4.0 - speed) * ((double) elapsed / 1000000.0 );


            // calculate the new duty value that the PWM should execute
            duty = u0 + (kp * (4.0 - speed)) + (ki * integ);


            // Don't allow the PWM to go beyond its maximum and minimum values
            if(duty > PWM_MAX) duty = PWM_MAX;
            if(duty < PWM_MIN) duty = PWM_MIN;
            // execute the PWM based on the calculated duty


            PWM_Motor_WriteCompare((uint16)duty);
            // set the hall flag back to 0
            hall_flag = 0;
        }

        // Navigation steering update
        if ((uint32)(msTicks - lastSteer) >= STEER_PERIOD_MS)
        {
            lastSteer += STEER_PERIOD_MS;
            steeringControl();
        }
    }
}


