/*******************************************************************************
* File Name: Line100.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Line100_H) /* Pins Line100_H */
#define CY_PINS_Line100_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Line100_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Line100__PORT == 15 && ((Line100__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Line100_Write(uint8 value);
void    Line100_SetDriveMode(uint8 mode);
uint8   Line100_ReadDataReg(void);
uint8   Line100_Read(void);
void    Line100_SetInterruptMode(uint16 position, uint16 mode);
uint8   Line100_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Line100_SetDriveMode() function.
     *  @{
     */
        #define Line100_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Line100_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Line100_DM_RES_UP          PIN_DM_RES_UP
        #define Line100_DM_RES_DWN         PIN_DM_RES_DWN
        #define Line100_DM_OD_LO           PIN_DM_OD_LO
        #define Line100_DM_OD_HI           PIN_DM_OD_HI
        #define Line100_DM_STRONG          PIN_DM_STRONG
        #define Line100_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Line100_MASK               Line100__MASK
#define Line100_SHIFT              Line100__SHIFT
#define Line100_WIDTH              1u

/* Interrupt constants */
#if defined(Line100__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Line100_SetInterruptMode() function.
     *  @{
     */
        #define Line100_INTR_NONE      (uint16)(0x0000u)
        #define Line100_INTR_RISING    (uint16)(0x0001u)
        #define Line100_INTR_FALLING   (uint16)(0x0002u)
        #define Line100_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Line100_INTR_MASK      (0x01u) 
#endif /* (Line100__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Line100_PS                     (* (reg8 *) Line100__PS)
/* Data Register */
#define Line100_DR                     (* (reg8 *) Line100__DR)
/* Port Number */
#define Line100_PRT_NUM                (* (reg8 *) Line100__PRT) 
/* Connect to Analog Globals */                                                  
#define Line100_AG                     (* (reg8 *) Line100__AG)                       
/* Analog MUX bux enable */
#define Line100_AMUX                   (* (reg8 *) Line100__AMUX) 
/* Bidirectional Enable */                                                        
#define Line100_BIE                    (* (reg8 *) Line100__BIE)
/* Bit-mask for Aliased Register Access */
#define Line100_BIT_MASK               (* (reg8 *) Line100__BIT_MASK)
/* Bypass Enable */
#define Line100_BYP                    (* (reg8 *) Line100__BYP)
/* Port wide control signals */                                                   
#define Line100_CTL                    (* (reg8 *) Line100__CTL)
/* Drive Modes */
#define Line100_DM0                    (* (reg8 *) Line100__DM0) 
#define Line100_DM1                    (* (reg8 *) Line100__DM1)
#define Line100_DM2                    (* (reg8 *) Line100__DM2) 
/* Input Buffer Disable Override */
#define Line100_INP_DIS                (* (reg8 *) Line100__INP_DIS)
/* LCD Common or Segment Drive */
#define Line100_LCD_COM_SEG            (* (reg8 *) Line100__LCD_COM_SEG)
/* Enable Segment LCD */
#define Line100_LCD_EN                 (* (reg8 *) Line100__LCD_EN)
/* Slew Rate Control */
#define Line100_SLW                    (* (reg8 *) Line100__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Line100_PRTDSI__CAPS_SEL       (* (reg8 *) Line100__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Line100_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Line100__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Line100_PRTDSI__OE_SEL0        (* (reg8 *) Line100__PRTDSI__OE_SEL0) 
#define Line100_PRTDSI__OE_SEL1        (* (reg8 *) Line100__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Line100_PRTDSI__OUT_SEL0       (* (reg8 *) Line100__PRTDSI__OUT_SEL0) 
#define Line100_PRTDSI__OUT_SEL1       (* (reg8 *) Line100__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Line100_PRTDSI__SYNC_OUT       (* (reg8 *) Line100__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Line100__SIO_CFG)
    #define Line100_SIO_HYST_EN        (* (reg8 *) Line100__SIO_HYST_EN)
    #define Line100_SIO_REG_HIFREQ     (* (reg8 *) Line100__SIO_REG_HIFREQ)
    #define Line100_SIO_CFG            (* (reg8 *) Line100__SIO_CFG)
    #define Line100_SIO_DIFF           (* (reg8 *) Line100__SIO_DIFF)
#endif /* (Line100__SIO_CFG) */

/* Interrupt Registers */
#if defined(Line100__INTSTAT)
    #define Line100_INTSTAT            (* (reg8 *) Line100__INTSTAT)
    #define Line100_SNAP               (* (reg8 *) Line100__SNAP)
    
	#define Line100_0_INTTYPE_REG 		(* (reg8 *) Line100__0__INTTYPE)
#endif /* (Line100__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Line100_H */


/* [] END OF FILE */
