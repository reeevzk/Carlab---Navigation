/*******************************************************************************
* File Name: GlitchFilterOut.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_GlitchFilterOut_ALIASES_H) /* Pins GlitchFilterOut_ALIASES_H */
#define CY_PINS_GlitchFilterOut_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define GlitchFilterOut_0			(GlitchFilterOut__0__PC)
#define GlitchFilterOut_0_INTR	((uint16)((uint16)0x0001u << GlitchFilterOut__0__SHIFT))

#define GlitchFilterOut_INTR_ALL	 ((uint16)(GlitchFilterOut_0_INTR))

#endif /* End Pins GlitchFilterOut_ALIASES_H */


/* [] END OF FILE */
