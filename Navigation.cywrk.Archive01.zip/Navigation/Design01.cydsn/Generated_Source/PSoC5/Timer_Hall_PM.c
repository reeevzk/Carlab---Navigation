/*******************************************************************************
* File Name: Timer_Hall_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_Hall.h"

static Timer_Hall_backupStruct Timer_Hall_backup;


/*******************************************************************************
* Function Name: Timer_Hall_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Hall_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_Hall_SaveConfig(void) 
{
    #if (!Timer_Hall_UsingFixedFunction)
        Timer_Hall_backup.TimerUdb = Timer_Hall_ReadCounter();
        Timer_Hall_backup.InterruptMaskValue = Timer_Hall_STATUS_MASK;
        #if (Timer_Hall_UsingHWCaptureCounter)
            Timer_Hall_backup.TimerCaptureCounter = Timer_Hall_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_Hall_UDB_CONTROL_REG_REMOVED)
            Timer_Hall_backup.TimerControlRegister = Timer_Hall_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_Hall_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Hall_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Hall_RestoreConfig(void) 
{   
    #if (!Timer_Hall_UsingFixedFunction)

        Timer_Hall_WriteCounter(Timer_Hall_backup.TimerUdb);
        Timer_Hall_STATUS_MASK =Timer_Hall_backup.InterruptMaskValue;
        #if (Timer_Hall_UsingHWCaptureCounter)
            Timer_Hall_SetCaptureCount(Timer_Hall_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_Hall_UDB_CONTROL_REG_REMOVED)
            Timer_Hall_WriteControlRegister(Timer_Hall_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_Hall_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Hall_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_Hall_Sleep(void) 
{
    #if(!Timer_Hall_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_Hall_CTRL_ENABLE == (Timer_Hall_CONTROL & Timer_Hall_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_Hall_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_Hall_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_Hall_Stop();
    Timer_Hall_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_Hall_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Hall_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Hall_Wakeup(void) 
{
    Timer_Hall_RestoreConfig();
    #if(!Timer_Hall_UDB_CONTROL_REG_REMOVED)
        if(Timer_Hall_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_Hall_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
