/*******************************************************************************
* File Name: GlitchFilterOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_GlitchFilterOut_H) /* Pins GlitchFilterOut_H */
#define CY_PINS_GlitchFilterOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "GlitchFilterOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 GlitchFilterOut__PORT == 15 && ((GlitchFilterOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    GlitchFilterOut_Write(uint8 value);
void    GlitchFilterOut_SetDriveMode(uint8 mode);
uint8   GlitchFilterOut_ReadDataReg(void);
uint8   GlitchFilterOut_Read(void);
void    GlitchFilterOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   GlitchFilterOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the GlitchFilterOut_SetDriveMode() function.
     *  @{
     */
        #define GlitchFilterOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define GlitchFilterOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define GlitchFilterOut_DM_RES_UP          PIN_DM_RES_UP
        #define GlitchFilterOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define GlitchFilterOut_DM_OD_LO           PIN_DM_OD_LO
        #define GlitchFilterOut_DM_OD_HI           PIN_DM_OD_HI
        #define GlitchFilterOut_DM_STRONG          PIN_DM_STRONG
        #define GlitchFilterOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define GlitchFilterOut_MASK               GlitchFilterOut__MASK
#define GlitchFilterOut_SHIFT              GlitchFilterOut__SHIFT
#define GlitchFilterOut_WIDTH              1u

/* Interrupt constants */
#if defined(GlitchFilterOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in GlitchFilterOut_SetInterruptMode() function.
     *  @{
     */
        #define GlitchFilterOut_INTR_NONE      (uint16)(0x0000u)
        #define GlitchFilterOut_INTR_RISING    (uint16)(0x0001u)
        #define GlitchFilterOut_INTR_FALLING   (uint16)(0x0002u)
        #define GlitchFilterOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define GlitchFilterOut_INTR_MASK      (0x01u) 
#endif /* (GlitchFilterOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define GlitchFilterOut_PS                     (* (reg8 *) GlitchFilterOut__PS)
/* Data Register */
#define GlitchFilterOut_DR                     (* (reg8 *) GlitchFilterOut__DR)
/* Port Number */
#define GlitchFilterOut_PRT_NUM                (* (reg8 *) GlitchFilterOut__PRT) 
/* Connect to Analog Globals */                                                  
#define GlitchFilterOut_AG                     (* (reg8 *) GlitchFilterOut__AG)                       
/* Analog MUX bux enable */
#define GlitchFilterOut_AMUX                   (* (reg8 *) GlitchFilterOut__AMUX) 
/* Bidirectional Enable */                                                        
#define GlitchFilterOut_BIE                    (* (reg8 *) GlitchFilterOut__BIE)
/* Bit-mask for Aliased Register Access */
#define GlitchFilterOut_BIT_MASK               (* (reg8 *) GlitchFilterOut__BIT_MASK)
/* Bypass Enable */
#define GlitchFilterOut_BYP                    (* (reg8 *) GlitchFilterOut__BYP)
/* Port wide control signals */                                                   
#define GlitchFilterOut_CTL                    (* (reg8 *) GlitchFilterOut__CTL)
/* Drive Modes */
#define GlitchFilterOut_DM0                    (* (reg8 *) GlitchFilterOut__DM0) 
#define GlitchFilterOut_DM1                    (* (reg8 *) GlitchFilterOut__DM1)
#define GlitchFilterOut_DM2                    (* (reg8 *) GlitchFilterOut__DM2) 
/* Input Buffer Disable Override */
#define GlitchFilterOut_INP_DIS                (* (reg8 *) GlitchFilterOut__INP_DIS)
/* LCD Common or Segment Drive */
#define GlitchFilterOut_LCD_COM_SEG            (* (reg8 *) GlitchFilterOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define GlitchFilterOut_LCD_EN                 (* (reg8 *) GlitchFilterOut__LCD_EN)
/* Slew Rate Control */
#define GlitchFilterOut_SLW                    (* (reg8 *) GlitchFilterOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define GlitchFilterOut_PRTDSI__CAPS_SEL       (* (reg8 *) GlitchFilterOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define GlitchFilterOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) GlitchFilterOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define GlitchFilterOut_PRTDSI__OE_SEL0        (* (reg8 *) GlitchFilterOut__PRTDSI__OE_SEL0) 
#define GlitchFilterOut_PRTDSI__OE_SEL1        (* (reg8 *) GlitchFilterOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define GlitchFilterOut_PRTDSI__OUT_SEL0       (* (reg8 *) GlitchFilterOut__PRTDSI__OUT_SEL0) 
#define GlitchFilterOut_PRTDSI__OUT_SEL1       (* (reg8 *) GlitchFilterOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define GlitchFilterOut_PRTDSI__SYNC_OUT       (* (reg8 *) GlitchFilterOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(GlitchFilterOut__SIO_CFG)
    #define GlitchFilterOut_SIO_HYST_EN        (* (reg8 *) GlitchFilterOut__SIO_HYST_EN)
    #define GlitchFilterOut_SIO_REG_HIFREQ     (* (reg8 *) GlitchFilterOut__SIO_REG_HIFREQ)
    #define GlitchFilterOut_SIO_CFG            (* (reg8 *) GlitchFilterOut__SIO_CFG)
    #define GlitchFilterOut_SIO_DIFF           (* (reg8 *) GlitchFilterOut__SIO_DIFF)
#endif /* (GlitchFilterOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(GlitchFilterOut__INTSTAT)
    #define GlitchFilterOut_INTSTAT            (* (reg8 *) GlitchFilterOut__INTSTAT)
    #define GlitchFilterOut_SNAP               (* (reg8 *) GlitchFilterOut__SNAP)
    
	#define GlitchFilterOut_0_INTTYPE_REG 		(* (reg8 *) GlitchFilterOut__0__INTTYPE)
#endif /* (GlitchFilterOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_GlitchFilterOut_H */


/* [] END OF FILE */
