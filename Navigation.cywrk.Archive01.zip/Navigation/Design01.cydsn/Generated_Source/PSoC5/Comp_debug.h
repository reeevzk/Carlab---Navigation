/*******************************************************************************
* File Name: Comp_debug.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Comp_debug_H) /* Pins Comp_debug_H */
#define CY_PINS_Comp_debug_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Comp_debug_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Comp_debug__PORT == 15 && ((Comp_debug__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Comp_debug_Write(uint8 value);
void    Comp_debug_SetDriveMode(uint8 mode);
uint8   Comp_debug_ReadDataReg(void);
uint8   Comp_debug_Read(void);
void    Comp_debug_SetInterruptMode(uint16 position, uint16 mode);
uint8   Comp_debug_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Comp_debug_SetDriveMode() function.
     *  @{
     */
        #define Comp_debug_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Comp_debug_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Comp_debug_DM_RES_UP          PIN_DM_RES_UP
        #define Comp_debug_DM_RES_DWN         PIN_DM_RES_DWN
        #define Comp_debug_DM_OD_LO           PIN_DM_OD_LO
        #define Comp_debug_DM_OD_HI           PIN_DM_OD_HI
        #define Comp_debug_DM_STRONG          PIN_DM_STRONG
        #define Comp_debug_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Comp_debug_MASK               Comp_debug__MASK
#define Comp_debug_SHIFT              Comp_debug__SHIFT
#define Comp_debug_WIDTH              1u

/* Interrupt constants */
#if defined(Comp_debug__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Comp_debug_SetInterruptMode() function.
     *  @{
     */
        #define Comp_debug_INTR_NONE      (uint16)(0x0000u)
        #define Comp_debug_INTR_RISING    (uint16)(0x0001u)
        #define Comp_debug_INTR_FALLING   (uint16)(0x0002u)
        #define Comp_debug_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Comp_debug_INTR_MASK      (0x01u) 
#endif /* (Comp_debug__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Comp_debug_PS                     (* (reg8 *) Comp_debug__PS)
/* Data Register */
#define Comp_debug_DR                     (* (reg8 *) Comp_debug__DR)
/* Port Number */
#define Comp_debug_PRT_NUM                (* (reg8 *) Comp_debug__PRT) 
/* Connect to Analog Globals */                                                  
#define Comp_debug_AG                     (* (reg8 *) Comp_debug__AG)                       
/* Analog MUX bux enable */
#define Comp_debug_AMUX                   (* (reg8 *) Comp_debug__AMUX) 
/* Bidirectional Enable */                                                        
#define Comp_debug_BIE                    (* (reg8 *) Comp_debug__BIE)
/* Bit-mask for Aliased Register Access */
#define Comp_debug_BIT_MASK               (* (reg8 *) Comp_debug__BIT_MASK)
/* Bypass Enable */
#define Comp_debug_BYP                    (* (reg8 *) Comp_debug__BYP)
/* Port wide control signals */                                                   
#define Comp_debug_CTL                    (* (reg8 *) Comp_debug__CTL)
/* Drive Modes */
#define Comp_debug_DM0                    (* (reg8 *) Comp_debug__DM0) 
#define Comp_debug_DM1                    (* (reg8 *) Comp_debug__DM1)
#define Comp_debug_DM2                    (* (reg8 *) Comp_debug__DM2) 
/* Input Buffer Disable Override */
#define Comp_debug_INP_DIS                (* (reg8 *) Comp_debug__INP_DIS)
/* LCD Common or Segment Drive */
#define Comp_debug_LCD_COM_SEG            (* (reg8 *) Comp_debug__LCD_COM_SEG)
/* Enable Segment LCD */
#define Comp_debug_LCD_EN                 (* (reg8 *) Comp_debug__LCD_EN)
/* Slew Rate Control */
#define Comp_debug_SLW                    (* (reg8 *) Comp_debug__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Comp_debug_PRTDSI__CAPS_SEL       (* (reg8 *) Comp_debug__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Comp_debug_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Comp_debug__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Comp_debug_PRTDSI__OE_SEL0        (* (reg8 *) Comp_debug__PRTDSI__OE_SEL0) 
#define Comp_debug_PRTDSI__OE_SEL1        (* (reg8 *) Comp_debug__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Comp_debug_PRTDSI__OUT_SEL0       (* (reg8 *) Comp_debug__PRTDSI__OUT_SEL0) 
#define Comp_debug_PRTDSI__OUT_SEL1       (* (reg8 *) Comp_debug__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Comp_debug_PRTDSI__SYNC_OUT       (* (reg8 *) Comp_debug__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Comp_debug__SIO_CFG)
    #define Comp_debug_SIO_HYST_EN        (* (reg8 *) Comp_debug__SIO_HYST_EN)
    #define Comp_debug_SIO_REG_HIFREQ     (* (reg8 *) Comp_debug__SIO_REG_HIFREQ)
    #define Comp_debug_SIO_CFG            (* (reg8 *) Comp_debug__SIO_CFG)
    #define Comp_debug_SIO_DIFF           (* (reg8 *) Comp_debug__SIO_DIFF)
#endif /* (Comp_debug__SIO_CFG) */

/* Interrupt Registers */
#if defined(Comp_debug__INTSTAT)
    #define Comp_debug_INTSTAT            (* (reg8 *) Comp_debug__INTSTAT)
    #define Comp_debug_SNAP               (* (reg8 *) Comp_debug__SNAP)
    
	#define Comp_debug_0_INTTYPE_REG 		(* (reg8 *) Comp_debug__0__INTTYPE)
#endif /* (Comp_debug__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Comp_debug_H */


/* [] END OF FILE */
