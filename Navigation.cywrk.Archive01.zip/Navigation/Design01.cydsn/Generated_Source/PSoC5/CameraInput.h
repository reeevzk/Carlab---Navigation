/*******************************************************************************
* File Name: CameraInput.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CameraInput_H) /* Pins CameraInput_H */
#define CY_PINS_CameraInput_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "CameraInput_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 CameraInput__PORT == 15 && ((CameraInput__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    CameraInput_Write(uint8 value);
void    CameraInput_SetDriveMode(uint8 mode);
uint8   CameraInput_ReadDataReg(void);
uint8   CameraInput_Read(void);
void    CameraInput_SetInterruptMode(uint16 position, uint16 mode);
uint8   CameraInput_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the CameraInput_SetDriveMode() function.
     *  @{
     */
        #define CameraInput_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define CameraInput_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define CameraInput_DM_RES_UP          PIN_DM_RES_UP
        #define CameraInput_DM_RES_DWN         PIN_DM_RES_DWN
        #define CameraInput_DM_OD_LO           PIN_DM_OD_LO
        #define CameraInput_DM_OD_HI           PIN_DM_OD_HI
        #define CameraInput_DM_STRONG          PIN_DM_STRONG
        #define CameraInput_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define CameraInput_MASK               CameraInput__MASK
#define CameraInput_SHIFT              CameraInput__SHIFT
#define CameraInput_WIDTH              1u

/* Interrupt constants */
#if defined(CameraInput__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in CameraInput_SetInterruptMode() function.
     *  @{
     */
        #define CameraInput_INTR_NONE      (uint16)(0x0000u)
        #define CameraInput_INTR_RISING    (uint16)(0x0001u)
        #define CameraInput_INTR_FALLING   (uint16)(0x0002u)
        #define CameraInput_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define CameraInput_INTR_MASK      (0x01u) 
#endif /* (CameraInput__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define CameraInput_PS                     (* (reg8 *) CameraInput__PS)
/* Data Register */
#define CameraInput_DR                     (* (reg8 *) CameraInput__DR)
/* Port Number */
#define CameraInput_PRT_NUM                (* (reg8 *) CameraInput__PRT) 
/* Connect to Analog Globals */                                                  
#define CameraInput_AG                     (* (reg8 *) CameraInput__AG)                       
/* Analog MUX bux enable */
#define CameraInput_AMUX                   (* (reg8 *) CameraInput__AMUX) 
/* Bidirectional Enable */                                                        
#define CameraInput_BIE                    (* (reg8 *) CameraInput__BIE)
/* Bit-mask for Aliased Register Access */
#define CameraInput_BIT_MASK               (* (reg8 *) CameraInput__BIT_MASK)
/* Bypass Enable */
#define CameraInput_BYP                    (* (reg8 *) CameraInput__BYP)
/* Port wide control signals */                                                   
#define CameraInput_CTL                    (* (reg8 *) CameraInput__CTL)
/* Drive Modes */
#define CameraInput_DM0                    (* (reg8 *) CameraInput__DM0) 
#define CameraInput_DM1                    (* (reg8 *) CameraInput__DM1)
#define CameraInput_DM2                    (* (reg8 *) CameraInput__DM2) 
/* Input Buffer Disable Override */
#define CameraInput_INP_DIS                (* (reg8 *) CameraInput__INP_DIS)
/* LCD Common or Segment Drive */
#define CameraInput_LCD_COM_SEG            (* (reg8 *) CameraInput__LCD_COM_SEG)
/* Enable Segment LCD */
#define CameraInput_LCD_EN                 (* (reg8 *) CameraInput__LCD_EN)
/* Slew Rate Control */
#define CameraInput_SLW                    (* (reg8 *) CameraInput__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define CameraInput_PRTDSI__CAPS_SEL       (* (reg8 *) CameraInput__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define CameraInput_PRTDSI__DBL_SYNC_IN    (* (reg8 *) CameraInput__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define CameraInput_PRTDSI__OE_SEL0        (* (reg8 *) CameraInput__PRTDSI__OE_SEL0) 
#define CameraInput_PRTDSI__OE_SEL1        (* (reg8 *) CameraInput__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define CameraInput_PRTDSI__OUT_SEL0       (* (reg8 *) CameraInput__PRTDSI__OUT_SEL0) 
#define CameraInput_PRTDSI__OUT_SEL1       (* (reg8 *) CameraInput__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define CameraInput_PRTDSI__SYNC_OUT       (* (reg8 *) CameraInput__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(CameraInput__SIO_CFG)
    #define CameraInput_SIO_HYST_EN        (* (reg8 *) CameraInput__SIO_HYST_EN)
    #define CameraInput_SIO_REG_HIFREQ     (* (reg8 *) CameraInput__SIO_REG_HIFREQ)
    #define CameraInput_SIO_CFG            (* (reg8 *) CameraInput__SIO_CFG)
    #define CameraInput_SIO_DIFF           (* (reg8 *) CameraInput__SIO_DIFF)
#endif /* (CameraInput__SIO_CFG) */

/* Interrupt Registers */
#if defined(CameraInput__INTSTAT)
    #define CameraInput_INTSTAT            (* (reg8 *) CameraInput__INTSTAT)
    #define CameraInput_SNAP               (* (reg8 *) CameraInput__SNAP)
    
	#define CameraInput_0_INTTYPE_REG 		(* (reg8 *) CameraInput__0__INTTYPE)
#endif /* (CameraInput__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_CameraInput_H */


/* [] END OF FILE */
