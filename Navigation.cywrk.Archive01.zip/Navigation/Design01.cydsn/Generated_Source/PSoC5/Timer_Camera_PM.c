/*******************************************************************************
* File Name: Timer_Camera_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_Camera.h"

static Timer_Camera_backupStruct Timer_Camera_backup;


/*******************************************************************************
* Function Name: Timer_Camera_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Camera_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_Camera_SaveConfig(void) 
{
    #if (!Timer_Camera_UsingFixedFunction)
        Timer_Camera_backup.TimerUdb = Timer_Camera_ReadCounter();
        Timer_Camera_backup.InterruptMaskValue = Timer_Camera_STATUS_MASK;
        #if (Timer_Camera_UsingHWCaptureCounter)
            Timer_Camera_backup.TimerCaptureCounter = Timer_Camera_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_Camera_UDB_CONTROL_REG_REMOVED)
            Timer_Camera_backup.TimerControlRegister = Timer_Camera_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_Camera_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Camera_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Camera_RestoreConfig(void) 
{   
    #if (!Timer_Camera_UsingFixedFunction)

        Timer_Camera_WriteCounter(Timer_Camera_backup.TimerUdb);
        Timer_Camera_STATUS_MASK =Timer_Camera_backup.InterruptMaskValue;
        #if (Timer_Camera_UsingHWCaptureCounter)
            Timer_Camera_SetCaptureCount(Timer_Camera_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_Camera_UDB_CONTROL_REG_REMOVED)
            Timer_Camera_WriteControlRegister(Timer_Camera_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_Camera_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Camera_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_Camera_Sleep(void) 
{
    #if(!Timer_Camera_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_Camera_CTRL_ENABLE == (Timer_Camera_CONTROL & Timer_Camera_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_Camera_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_Camera_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_Camera_Stop();
    Timer_Camera_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_Camera_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Camera_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Camera_Wakeup(void) 
{
    Timer_Camera_RestoreConfig();
    #if(!Timer_Camera_UDB_CONTROL_REG_REMOVED)
        if(Timer_Camera_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_Camera_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
