/*******************************************************************************
* File Name: line_scan_signal.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_line_scan_signal_H) /* Pins line_scan_signal_H */
#define CY_PINS_line_scan_signal_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "line_scan_signal_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 line_scan_signal__PORT == 15 && ((line_scan_signal__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    line_scan_signal_Write(uint8 value);
void    line_scan_signal_SetDriveMode(uint8 mode);
uint8   line_scan_signal_ReadDataReg(void);
uint8   line_scan_signal_Read(void);
void    line_scan_signal_SetInterruptMode(uint16 position, uint16 mode);
uint8   line_scan_signal_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the line_scan_signal_SetDriveMode() function.
     *  @{
     */
        #define line_scan_signal_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define line_scan_signal_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define line_scan_signal_DM_RES_UP          PIN_DM_RES_UP
        #define line_scan_signal_DM_RES_DWN         PIN_DM_RES_DWN
        #define line_scan_signal_DM_OD_LO           PIN_DM_OD_LO
        #define line_scan_signal_DM_OD_HI           PIN_DM_OD_HI
        #define line_scan_signal_DM_STRONG          PIN_DM_STRONG
        #define line_scan_signal_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define line_scan_signal_MASK               line_scan_signal__MASK
#define line_scan_signal_SHIFT              line_scan_signal__SHIFT
#define line_scan_signal_WIDTH              1u

/* Interrupt constants */
#if defined(line_scan_signal__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in line_scan_signal_SetInterruptMode() function.
     *  @{
     */
        #define line_scan_signal_INTR_NONE      (uint16)(0x0000u)
        #define line_scan_signal_INTR_RISING    (uint16)(0x0001u)
        #define line_scan_signal_INTR_FALLING   (uint16)(0x0002u)
        #define line_scan_signal_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define line_scan_signal_INTR_MASK      (0x01u) 
#endif /* (line_scan_signal__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define line_scan_signal_PS                     (* (reg8 *) line_scan_signal__PS)
/* Data Register */
#define line_scan_signal_DR                     (* (reg8 *) line_scan_signal__DR)
/* Port Number */
#define line_scan_signal_PRT_NUM                (* (reg8 *) line_scan_signal__PRT) 
/* Connect to Analog Globals */                                                  
#define line_scan_signal_AG                     (* (reg8 *) line_scan_signal__AG)                       
/* Analog MUX bux enable */
#define line_scan_signal_AMUX                   (* (reg8 *) line_scan_signal__AMUX) 
/* Bidirectional Enable */                                                        
#define line_scan_signal_BIE                    (* (reg8 *) line_scan_signal__BIE)
/* Bit-mask for Aliased Register Access */
#define line_scan_signal_BIT_MASK               (* (reg8 *) line_scan_signal__BIT_MASK)
/* Bypass Enable */
#define line_scan_signal_BYP                    (* (reg8 *) line_scan_signal__BYP)
/* Port wide control signals */                                                   
#define line_scan_signal_CTL                    (* (reg8 *) line_scan_signal__CTL)
/* Drive Modes */
#define line_scan_signal_DM0                    (* (reg8 *) line_scan_signal__DM0) 
#define line_scan_signal_DM1                    (* (reg8 *) line_scan_signal__DM1)
#define line_scan_signal_DM2                    (* (reg8 *) line_scan_signal__DM2) 
/* Input Buffer Disable Override */
#define line_scan_signal_INP_DIS                (* (reg8 *) line_scan_signal__INP_DIS)
/* LCD Common or Segment Drive */
#define line_scan_signal_LCD_COM_SEG            (* (reg8 *) line_scan_signal__LCD_COM_SEG)
/* Enable Segment LCD */
#define line_scan_signal_LCD_EN                 (* (reg8 *) line_scan_signal__LCD_EN)
/* Slew Rate Control */
#define line_scan_signal_SLW                    (* (reg8 *) line_scan_signal__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define line_scan_signal_PRTDSI__CAPS_SEL       (* (reg8 *) line_scan_signal__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define line_scan_signal_PRTDSI__DBL_SYNC_IN    (* (reg8 *) line_scan_signal__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define line_scan_signal_PRTDSI__OE_SEL0        (* (reg8 *) line_scan_signal__PRTDSI__OE_SEL0) 
#define line_scan_signal_PRTDSI__OE_SEL1        (* (reg8 *) line_scan_signal__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define line_scan_signal_PRTDSI__OUT_SEL0       (* (reg8 *) line_scan_signal__PRTDSI__OUT_SEL0) 
#define line_scan_signal_PRTDSI__OUT_SEL1       (* (reg8 *) line_scan_signal__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define line_scan_signal_PRTDSI__SYNC_OUT       (* (reg8 *) line_scan_signal__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(line_scan_signal__SIO_CFG)
    #define line_scan_signal_SIO_HYST_EN        (* (reg8 *) line_scan_signal__SIO_HYST_EN)
    #define line_scan_signal_SIO_REG_HIFREQ     (* (reg8 *) line_scan_signal__SIO_REG_HIFREQ)
    #define line_scan_signal_SIO_CFG            (* (reg8 *) line_scan_signal__SIO_CFG)
    #define line_scan_signal_SIO_DIFF           (* (reg8 *) line_scan_signal__SIO_DIFF)
#endif /* (line_scan_signal__SIO_CFG) */

/* Interrupt Registers */
#if defined(line_scan_signal__INTSTAT)
    #define line_scan_signal_INTSTAT            (* (reg8 *) line_scan_signal__INTSTAT)
    #define line_scan_signal_SNAP               (* (reg8 *) line_scan_signal__SNAP)
    
	#define line_scan_signal_0_INTTYPE_REG 		(* (reg8 *) line_scan_signal__0__INTTYPE)
#endif /* (line_scan_signal__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_line_scan_signal_H */


/* [] END OF FILE */
